$(document).ready(function() {
    // Función para cargar los clientes desde la base de datos
    function cargarClientes() {
        // Hacer una petición AJAX al backend para obtener los clientes
        $.ajax({
            url: '/api/clientes', // Endpoint del backend para obtener clientes
            method: 'GET',
            success: function(data) {
                // Limpiar la tabla
                $('#clientesTableBody').empty();
                // Iterar sobre los datos y agregar cada cliente a la tabla
                data.forEach(function(cliente) {
                    $('#clientesTableBody').append(`
                        <tr>
                            <td>${cliente.id_cliente}</td>
                            <td>${cliente.nombre}</td>
                            <td>${cliente.direccion}</td>
                            <td>${cliente.email}</td>
                            <td>${cliente.telefono}</td>
                            <td>
                                <button class="btn btn-sm btn-info editarBtn" data-id="${cliente.id_cliente}">Editar</button>
                                <button class="btn btn-sm btn-danger eliminarBtn" data-id="${cliente.id_cliente}">Eliminar</button>
                            </td>
                        </tr>
                    `);
                });
            },
            error: function(err) {
                console.error('Error al cargar clientes:', err);
            }
        });
    }

    // Cargar los clientes al cargar la página
    cargarClientes();

    // Manejar el envío del formulario para agregar un nuevo cliente
    $('#clienteForm').submit(function(event) {
        event.preventDefault();
        // Obtener los datos del formulario
        const nombre = $('#nombreCliente').val();
        const direccion = $('#direccionCliente').val();
        const email = $('#emailCliente').val();
        const telefono = $('#telefonoCliente').val();
        
        // Validar el formato del teléfono
        if (!/^\d{10}$/.test(telefono)) {
            alert('El teléfono debe tener 10 dígitos.');
            return;
        }
        
        // Hacer una petición AJAX para agregar el cliente
        $.ajax({
            url: '/api/clientes', // Endpoint del backend para agregar clientes
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ nombre, direccion, email, telefono }),
            success: function(data) {
                // Limpiar el formulario
                $('#nombreCliente').val('');
                $('#direccionCliente').val('');
                $('#emailCliente').val('');
                $('#telefonoCliente').val('');
                // Volver a cargar los clientes
                cargarClientes();
            },
            error: function(err) {
                console.error('Error al agregar cliente:', err);
            }
        });
    });

    // Evento delegado para botones de editar y eliminar
    $('#clientesTableBody').on('click', '.editarBtn', function() {
        const idCliente = $(this).data('id');
        // Implementar lógica para editar un cliente (opcional)
        // Puedes abrir un modal con el formulario de edición
        // y manejar la actualización haciendo otra petición AJAX
        console.log('Editar cliente con ID:', idCliente);
    });

    $('#clientesTableBody').on('click', '.eliminarBtn', function() {
        const idCliente = $(this).data('id');
        $.ajax({
            url: `/api/clientes/${idCliente}`, // Endpoint del backend para eliminar clientes
            method: 'DELETE',
            success: function(data) {
                // Volver a cargar los clientes después de eliminar
                cargarClientes();
            },
            error: function(err) {
                console.error('Error al eliminar cliente:', err);
            }
        });
    });
});
