$(document).ready(function() {
    // Función para cargar los trabajadores y los trabajos desde la base de datos
    function cargarTrabajadoresYTrabajos() {
        $.ajax({
            url: '/api/trabajadores', // Endpoint para obtener trabajadores
            method: 'GET',
            success: function(data) {
                $('#trabajadorSelect, #editTrabajadorSelect').empty();
                data.forEach(function(trabajador) {
                    $('#trabajadorSelect, #editTrabajadorSelect').append(`
                        <option value="${trabajador.id_trabajador}">${trabajador.nombre} ${trabajador.apellido}</option>
                    `);
                });
            },
            error: function(err) {
                console.error('Error al cargar trabajadores:', err);
            }
        });

        $.ajax({
            url: '/api/trabajos', // Endpoint para obtener trabajos
            method: 'GET',
            success: function(data) {
                $('#trabajoSelect, #editTrabajoSelect').empty();
                data.forEach(function(trabajo) {
                    $('#trabajoSelect, #editTrabajoSelect').append(`
                        <option value="${trabajo.id_trabajo}">${trabajo.nombre}</option>
                    `);
                });
            },
            error: function(err) {
                console.error('Error al cargar trabajos:', err);
            }
        });
    }

    // Función para cargar las asignaciones desde la base de datos
    function cargarAsignaciones() {
        $.ajax({
            url: '/api/asignaciones', // Endpoint para obtener asignaciones
            method: 'GET',
            success: function(data) {
                $('#asignacionesTableBody').empty();
                data.forEach(function(asignacion) {
                    $('#asignacionesTableBody').append(`
                        <tr>
                            <td>${asignacion.id_asignacion}</td>
                            <td>${asignacion.trabajador_nombre} ${asignacion.trabajador_apellido}</td>
                            <td>${asignacion.trabajo_nombre}</td>
                            <td>${asignacion.fecha_asignacion}</td>
                            <td>
                                <button class="btn btn-sm btn-info editarBtn" data-id="${asignacion.id_asignacion}" data-trabajador-id="${asignacion.trabajador_id}" data-trabajo-id="${asignacion.trabajo_id}" data-fecha-asignacion="${asignacion.fecha_asignacion}">Editar</button>
                                <button class="btn btn-sm btn-danger eliminarBtn" data-id="${asignacion.id_asignacion}">Eliminar</button>
                            </td>
                        </tr>
                    `);
                });
            },
            error: function(err) {
                console.error('Error al cargar asignaciones:', err);
            }
        });
    }

    // Cargar trabajadores, trabajos y asignaciones al cargar la página
    cargarTrabajadoresYTrabajos();
    cargarAsignaciones();

    // Manejar el envío del formulario para agregar una nueva asignación
    $('#asignacionForm').submit(function(event) {
        event.preventDefault();
        const trabajadorId = $('#trabajadorSelect').val();
        const trabajoId = $('#trabajoSelect').val();
        const fechaAsignacion = $('#fechaAsignacion').val();

        $.ajax({
            url: '/api/asignaciones', // Endpoint para agregar asignaciones
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ trabajador_id: trabajadorId, trabajo_id: trabajoId, fecha_asignacion: fechaAsignacion }),
            success: function(data) {
                $('#trabajadorSelect').val('');
                $('#trabajoSelect').val('');
                $('#fechaAsignacion').val('');
                cargarAsignaciones();
            },
            error: function(err) {
                console.error('Error al agregar asignación:', err);
            }
        });
    });

    // Evento delegado para botones de editar
    $('#asignacionesTableBody').on('click', '.editarBtn', function() {
        const idAsignacion = $(this).data('id');
        const trabajadorId = $(this).data('trabajador-id');
        const trabajoId = $(this).data('trabajo-id');
        const fechaAsignacion = $(this).data('fecha-asignacion');

        // Llenar los campos del modal con los datos actuales de la asignación
        $('#editAsignacionId').val(idAsignacion);
        $('#editTrabajadorSelect').val(trabajadorId);
        $('#editTrabajoSelect').val(trabajoId);
        $('#editFechaAsignacion').val(fechaAsignacion);

        // Mostrar el modal de edición
        $('#editAsignacionModal').modal('show');
    });

    // Manejar el envío del formulario de edición
    $('#editAsignacionForm').submit(function(event) {
        event.preventDefault();
        const idAsignacion = $('#editAsignacionId').val();
        const trabajadorId = $('#editTrabajadorSelect').val();
        const trabajoId = $('#editTrabajoSelect').val();
        const fechaAsignacion = $('#editFechaAsignacion').val();

        $.ajax({
            url: `/api/asignaciones/${idAsignacion}`, // Endpoint para actualizar asignaciones
            method: 'PUT',
            contentType: 'application/json',
            data: JSON.stringify({ trabajador_id: trabajadorId, trabajo_id: trabajoId, fecha_asignacion: fechaAsignacion }),
            success: function(data) {
                $('#editAsignacionModal').modal('hide');
                cargarAsignaciones();
            },
            error: function(err) {
                console.error('Error al actualizar asignación:', err);
            }
        });
    });

    // Evento delegado para botones de eliminar
    $('#asignacionesTableBody').on('click', '.eliminarBtn', function() {
        const idAsignacion = $(this).data('id');
        $.ajax({
            url: `/api/asignaciones/${idAsignacion}`, // Endpoint para eliminar asignaciones
            method: 'DELETE',
            success: function(data) {
                cargarAsignaciones();
            },
            error: function(err) {
                console.error('Error al eliminar asignación:', err);
            }
        });
    });
});
