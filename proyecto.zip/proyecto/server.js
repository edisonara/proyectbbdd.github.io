const express = require('express');
const bodyParser = require('body-parser');
const { Client } = require('pg');
const path = require('path');

const app = express();
const port = 3001;

// Configuración de PostgreSQL
const client = new Client({
    host: '172.17.0.2', // O '127.0.0.1' o la dirección IP de tu contenedor Docker si es diferente
    port: 5432,
    user: 'postgres',
    password: 'contrasena',
    database: 'ProyectoG6'
});

client.connect().then(() => {
    console.log("Connected to PostgreSQL database");
}).catch(err => {
    console.error('Connection error', err.stack);
});

// Middleware para parsear JSON
app.use(bodyParser.json());

// Servir archivos estáticos desde el directorio "public"
app.use(express.static(path.join(__dirname, 'public')));

// Añadir encabezado CSP
app.use((req, res, next) => {
    res.setHeader("Content-Security-Policy", "default-src 'self'; img-src 'self' data:; script-src 'self'; style-src 'self';");
    next();
});

// Ruta para servir el archivo HTML
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname,'public', 'index.html'));
});

app.get('/about', (req, res) => {
    res.sendFile(__dirname + '/public/form.html');
});


app.get('/nuevo', (req, res) => {
    res.sendFile(__dirname + '/public/alimentacion.html');
});

app.get('/nuevo', (req, res) => {
    res.sendFile(__dirname + '/public/asignacion.html');
});

app.get('/nuevo', (req, res) => {
    res.sendFile(__dirname + '/public/nosotros.html');
});

app.use(express.static('public'));
// Ruta para manejar el formulario de envío
app.post('/submit', async (req, res) => {
    const { name, email } = req.body;

    try {
        const query = 'INSERT INTO users (name, email) VALUES ($1, $2)';
        await client.query(query, [name, email]);
        res.json({ message: 'Datos ingresados exitosamente' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error al ingresar los datos' });
    }
});

// Ruta para obtener todos los datos
app.get('/users', async (req, res) => {
    try {
        const result = await client.query('SELECT * FROM users');
        res.json(result.rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error al obtener los datos' });
    }
});

 // Endpoint para obtener alimentos
app.get('/api/alimentos', async (req, res) => {
    try {
        const result = await client.query('SELECT * FROM Cosecha.Alimentacion');
        res.json(result.rows);
    } catch (err) {
        console.error('Error al obtener alimentos:', err);
        res.status(500).json({ message: 'Error al obtener alimentos' });
    }
});

// Endpoint para agregar un nuevo alimento
app.post('/api/alimentos', async (req, res) => {
    const { tipo_alimento } = req.body;
    try {
        const query = 'INSERT INTO Cosecha.Alimentacion (tipo_alimento) VALUES ($1)';
        await client.query(query, [tipo_alimento]);
        res.json({ message: 'Alimento agregado exitosamente' });
    } catch (err) {
        console.error('Error al agregar alimento:', err);
        res.status(500).json({ message: 'Error al agregar alimento' });
    }
});

// Endpoint para eliminar un alimento
app.delete('/api/alimentos/:id', async (req, res) => {
    const { id } = req.params;
    try {
        const query = 'DELETE FROM Cosecha.Alimentacion WHERE id_alimentacion = $1';
        await client.query(query, [id]);
        res.json({ message: 'Alimento eliminado exitosamente' });
    } catch (err) {
        console.error('Error al eliminar alimento:', err);
        res.status(500).json({ message: 'Error al eliminar alimento' });
    }
});
 
app.listen(port, () => {
    console.log(`Servidor corriendo en http://localhost:${port}`);
});
