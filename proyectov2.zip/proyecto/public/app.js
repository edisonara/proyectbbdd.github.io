app.post('/controlSalud', async (req, res) => {
  const { estanqueId, fechaControl, resultado, estabilidad } = req.body;

  try {
    const query = `
      INSERT INTO Cosecha.Control_Salud (estanque_id, fecha_control, resultado, estabilidad)
      VALUES ($1, $2, $3, $4)
      ON CONFLICT (estanque_id) DO UPDATE
      SET fecha_control = $2, resultado = $3, estabilidad = $4
      RETURNING *;
    `;
    const values = [estanqueId, fechaControl, resultado, estabilidad];
    const result = await pool.query(query, values);
    res.json({ success: true, result: result.rows[0] });
  } catch (err) {
    console.error('Error al ingresar/actualizar control de salud:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});
app.get('/controlesSalud', async (req, res) => {
  try {
    const query = 'SELECT * FROM Cosecha.Control_Salud;';
    const result = await pool.query(query);
    res.json(result.rows);
  } catch (err) {
    console.error('Error al obtener controles de salud:', err);
    res.status(500).json({ error: err.message });
  }
});
app.get('/controlSaludPorEstanque/:idEstanque', async (req, res) => {
  const idEstanque = req.params.idEstanque;

  try {
    const query = 'SELECT * FROM Cosecha.Control_Salud WHERE estanque_id = $1;';
    const result = await pool.query(query, [idEstanque]);
    res.json(result.rows);
  } catch (err) {
    console.error('Error al buscar control de salud por ID de estanque:', err);
    res.status(500).json({ error: err.message });
  }
});
app.get('/controlSaludPorPez/:nombrePez', async (req, res) => {
  const nombrePez = req.params.nombrePez;

  try {
    const query = `
      SELECT cs.*
      FROM Cosecha.Control_Salud cs
      JOIN Cosecha.Estanques e ON cs.estanque_id = e.id_estanque
      JOIN Cosecha.Peces p ON e.pez_id = p.id_pez
      WHERE p.nombre ILIKE $1;
    `;
    const result = await pool.query(query, [`%${nombrePez}%`]);
    res.json(result.rows);
  } catch (err) {
    console.error('Error al buscar control de salud por nombre del pez:', err);
    res.status(500).json({ error: err.message });
  }
});
