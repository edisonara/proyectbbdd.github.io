document.getElementById('dataForm').addEventListener('submit', async function (event) {
    event.preventDefault();
    
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;

    const response = await fetch('/submit', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ name, email })
    });

    const result = await response.json();
    alert(result.message);
});

document.getElementById('loadData').addEventListener('click', async function () {
    const response = await fetch('/users');
    const users = await response.json();

    const dataTable = document.getElementById('dataTable').getElementsByTagName('tbody')[0];
    dataTable.innerHTML = ''; // Clear existing data

    users.forEach(user => {
        const row = dataTable.insertRow();
        const idCell = row.insertCell(0);
        const nameCell = row.insertCell(1);
        const emailCell = row.insertCell(2);

        idCell.textContent = user.id;
        nameCell.textContent = user.name;
        emailCell.textContent = user.email;
    });
});

