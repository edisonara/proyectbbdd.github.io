// public/main.js
document.getElementById('form-add-pez').addEventListener('submit', async function(e) {
    e.preventDefault();

    const nombre = document.getElementById('nombre').value;
    const informacion = document.getElementById('informacion').value;

    const response = await fetch('/api/peces', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ nombre, informacion })
    });

    if (response.ok) {
        alert('Pez agregado exitosamente');
        document.getElementById('form-add-pez').reset();
    } else {
        alert('Error al agregar el pez');
    }
});
