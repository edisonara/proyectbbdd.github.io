// server.js
const express = require('express');
const bodyParser = require('body-parser');
const pool = require('./db');

const app = express();
const PORT = 3000;

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public')); // Carpeta para archivos estáticos como HTML, CSS, etc.

// Ruta de prueba
app.get('/api/test', (req, res) => {
  pool.query('SELECT NOW()', (err, result) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json(result.rows);
  });
});

// Endpoint para agregar peces
app.post('/api/peces', (req, res) => {
  const { nombre, informacion } = req.body;
  pool.query(
    'INSERT INTO Peces (nombre, informacion) VALUES ($1, $2) RETURNING *',
    [nombre, informacion],
    (err, result) => {
      if (err) {
        return res.status(500).json({ error: err.message });
      }
      res.status(201).json(result.rows[0]);
    }
  );
});

// Iniciar el servidor
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
