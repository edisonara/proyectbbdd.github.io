$(document).ready(function() {
    // Función para cargar los clientes desde la base de datos
    function cargarClientes() {
        // Hacer una petición AJAX al backend para obtener los clientes
        $.ajax({
            url: '/api/clientes', // Endpoint del backend para obtener clientes
            method: 'GET',
            success: function(data) {
                // Limpiar la tabla
                $('#clientesTableBody').empty();
                // Iterar sobre los datos y agregar cada cliente a la tabla
                data.forEach(function(cliente) {
                    $('#clientesTableBody').append(`
                        <tr>
                            <td>${cliente.id_cliente}</td>
                            <td>${cliente.nombre}</td>
                            <td>${cliente.direccion}</td>
                            <td>${cliente.email}</td>
                            <td>${cliente.telefono}</td>
                            <td>
                                <button class="btn btn-sm btn-info editarBtn" data-id="${cliente.id_cliente}">Editar</button>
                                <button class="btn btn-sm btn-danger eliminarBtn" data-id="${cliente.id_cliente}">Eliminar</button>
                            </td>
                        </tr>
                    `);
                });
            },
            error: function(err) {
                console.error('Error al cargar clientes:', err);
            }
        });
    }

    // Cargar los clientes al cargar la página
    cargarClientes();

    // Manejar el envío del formulario para agregar un nuevo cliente
    $('#clienteForm').submit(function(event) {
        event.preventDefault();
        // Obtener los datos del formulario
        const nombre = $('#nombreCliente').val();
        const direccion = $('#direccionCliente').val();
        const email = $('#emailCliente').val();
        const telefono = $('#telefonoCliente').val();
        // Hacer una petición AJAX para agregar el cliente
        $.ajax({
            url: '/api/clientes', // Endpoint del backend para agregar clientes
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ nombre, direccion, email, telefono }),
            success: function(data) {
                // Limpiar el formulario
                $('#nombreCliente').val('');
                $('#direccionCliente').val('');
                $('#emailCliente').val('');
                $('#telefonoCliente').val('');
                // Volver a cargar los clientes
                cargarClientes();
            },
            error: function(err) {
                console.error('Error al agregar cliente:', err);
            }
        });
    });

    // Manejar el clic en el botón de eliminar
    $(document).on('click', '.eliminarBtn', function() {
        const id = $(this).data('id');
        // Hacer una petición AJAX para eliminar el cliente
        $.ajax({
            url: `/api/clientes/${id}`, // Endpoint del backend para eliminar clientes
            method: 'DELETE',
            success: function(data) {
                // Volver a cargar los clientes
                cargarClientes();
            },
            error: function(err) {
                console.error('Error al eliminar cliente:', err);
            }
        });
    });

    // Manejar el clic en el botón de editar
    $(document).on('click', '.editarBtn', function() {
        const id = $(this).data('id');
        // Obtener los datos del cliente actual para pre-llenar el formulario
        const row = $(this).closest('tr');
        const nombre = row.find('td:eq(1)').text();
        const direccion = row.find('td:eq(2)').text();
        const email = row.find('td:eq(3)').text();
        const telefono = row.find('td:eq(4)').text();

        // Llenar el formulario del modal con los datos del cliente
        $('#editId').val(id);
        $('#editNombre').val(nombre);
        $('#editDireccion').val(direccion);
        $('#editEmail').val(email);
        $('#editTelefono').val(telefono);

        // Mostrar el modal
        $('#editModal').modal('show');
    });

    // Manejar el envío del formulario de edición
    $('#editForm').submit(function(event) {
        event.preventDefault();
        // Obtener los datos del formulario
        const id = $('#editId').val();
        const nombre = $('#editNombre').val();
        const direccion = $('#editDireccion').val();
        const email = $('#editEmail').val();
        const telefono = $('#editTelefono').val();

        // Hacer una petición AJAX para actualizar el cliente
        $.ajax({
            url: `/api/clientes/${id}`, // Endpoint del backend para actualizar clientes
            method: 'PUT',
            contentType: 'application/json',
            data: JSON.stringify({ nombre, direccion, email, telefono }),
            success: function(data) {
                // Ocultar el modal
                $('#editModal').modal('hide');
                // Volver a cargar los clientes
                cargarClientes();
            },
            error: function(err) {
                console.error('Error al actualizar cliente:', err);
            }
        });
    });
});
