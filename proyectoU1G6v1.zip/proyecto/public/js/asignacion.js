document.addEventListener('DOMContentLoaded', () => {
    const loader = document.getElementById('loader');
    const content = document.getElementById('content');
    const asignacionForm = document.getElementById('asignacionForm');
    const asignacionesTableBody = document.getElementById('asignacionesTableBody');
    const trabajadorSelect = document.getElementById('trabajadorSelect');
    const trabajoSelect = document.getElementById('trabajoSelect');


    const apiUrl = 'http://localhost:3001/api/asignaciones';

    // Función para cargar las asignaciones desde el servidor
    const cargarAsignaciones = async () => {
        try {
            const response = await fetch(apiUrl);
            if (!response.ok) {
                throw new Error('Error al obtener las asignaciones');
            }
            const asignaciones = await response.json();
            mostrarAsignaciones(asignaciones);
        } catch (error) {
            console.error('Error:', error);
        }
    };

    // Función para mostrar las asignaciones en la tabla
    const mostrarAsignaciones = (asignaciones) => {
        asignacionesTableBody.innerHTML = '';
        asignaciones.forEach(asignacion => {
            const row = `
                <tr>
                    <td>${asignacion.id_asignacion}</td>
                    <td>${asignacion.trabajador}</td>
                    <td>${asignacion.trabajo}</td>
                    <td>${asignacion.fecha_asignacion}</td>
                    <td>
                        <button type="button" class="btn btn-sm btn-primary editar-btn" data-id="${asignacion.id_asignacion}">Editar</button>
                        <button type="button" class="btn btn-sm btn-danger eliminar-btn" data-id="${asignacion.id_asignacion}">Eliminar</button>
                    </td>
                </tr>
            `;
            asignacionesTableBody.innerHTML += row;
        });
    };

    // Función para cargar trabajadores y trabajos en los select del formulario
    const cargarTrabajadoresYTrabajos = async () => {
        try {
            const trabajadoresResponse = await fetch('http://localhost:3001/api/trabajadores');
            const trabajosResponse = await fetch('http://localhost:3001/api/trabajos');
            if (!trabajadoresResponse.ok || !trabajosResponse.ok) {
                throw new Error('Error al obtener trabajadores o trabajos');
            }
            const trabajadores = await trabajadoresResponse.json();
            const trabajos = await trabajosResponse.json();
            llenarSelect(trabajadores, trabajadorSelect);
            llenarSelect(trabajos, trabajoSelect);
        } catch (error) {
            console.error('Error:', error);
        }
    };

    // Función para llenar un select con opciones
    const llenarSelect = (options, selectElement) => {
        selectElement.innerHTML = '';
        options.forEach(option => {
            const optionElement = document.createElement('option');
            optionElement.value = option.id;
            optionElement.textContent = option.nombre;
            selectElement.appendChild(optionElement);
        });
    };

    // Función para enviar el formulario de asignación al servidor
    const enviarFormularioAsignacion = async (event) => {
        event.preventDefault();
        const formData = new FormData(asignacionForm);
        const data = {
            id_trabajador: formData.get('trabajadorSelect'),
            id_trabajo: formData.get('trabajoSelect'),
            fecha_asignacion: formData.get('fechaAsignacion')
        };

        try {
            const response = await fetch(apiUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });

            if (!response.ok) {
                throw new Error('Error al agregar asignación');
            }

            const nuevaAsignacion = await response.json();
            cargarAsignaciones();
            asignacionForm.reset();
        } catch (error) {
            console.error('Error:', error);
        }
    };

    // Función para eliminar una asignación
    const eliminarAsignacion = async (id) => {
        try {
            const response = await fetch(`${apiUrl}/${id}`, {
                method: 'DELETE'
            });

            if (!response.ok) {
                throw new Error('Error al eliminar asignación');
            }

            cargarAsignaciones();
        } catch (error) {
            console.error('Error:', error);
        }
    };

    // Función para manejar eventos de clic en la tabla de asignaciones
    asignacionesTableBody.addEventListener('click', async (event) => {
        if (event.target.classList.contains('eliminar-btn')) {
            const id = event.target.getAttribute('data-id');
            if (confirm(`¿Estás seguro de eliminar la asignación con ID ${id}?`)) {
                eliminarAsignacion(id);
            }
        } else if (event.target.classList.contains('editar-btn')) {
            const id = event.target.getAttribute('data-id');
            const asignacion = await obtenerAsignacionPorId(id);
            mostrarFormularioEdicion(asignacion);
        }
    });

    // Función para obtener los datos de una asignación por su ID
    const obtenerAsignacionPorId = async (id) => {
        try {
            const response = await fetch(`${apiUrl}/${id}`);
            if (!response.ok) {
                throw new Error('Error al obtener la asignación');
            }
            const asignacion = await response.json();
            return asignacion;
        } catch (error) {
            console.error('Error:', error);
            return null;
        }
    };

    // Función para mostrar el formulario de edición con los datos de la asignación
    const mostrarFormularioEdicion = (asignacion) => {
        const editAsignacionForm = document.getElementById('editAsignacionForm');
        const editAsignacionId = document.getElementById('editAsignacionId');
        const editTrabajadorSelect = document.getElementById('editTrabajadorSelect');
        const editTrabajoSelect = document.getElementById('editTrabajoSelect');
        const editFechaAsignacion = document.getElementById('editFechaAsignacion');

        editAsignacionId.value = asignacion.id_asignacion;
        editFechaAsignacion.value = asignacion.fecha_asignacion;

        // Cargar trabajadores y trabajos en los select de edición
        cargarTrabajadoresYTrabajos();

        // Seleccionar el trabajador y trabajo correspondientes en los select
        editTrabajadorSelect.value = asignacion.trabajador_id.toString();
        editTrabajoSelect.value = asignacion.trabajo_id.toString();

        // Mostrar el modal de edición
        $('#editAsignacionModal').modal('show');

        // Manejar el envío del formulario de edición
        editAsignacionForm.addEventListener('submit', async (event) => {
            event.preventDefault();
            const formData = new FormData(editAsignacionForm);
            const data = {
                id_trabajador: formData.get('editTrabajadorSelect'),
                id_trabajo: formData.get('editTrabajoSelect'),
                fecha_asignacion: formData.get('fechaAsignacion')
            };

            try {
                const response = await fetch(`${apiUrl}/${asignacion.asignacion_id}`, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(data)
                });

                if (!response.ok) {
                    throw new Error('Error al actualizar asignación');
                }

                $('#editAsignacionModal').modal('hide');
                cargarAsignaciones();
            } catch (error) {
                console.error('Error:', error);
            }
        });
    };

    // Cargar trabajadores y trabajos al cargar la página
    cargarTrabajadoresYTrabajos();

    // Cargar asignaciones al cargar la página
    cargarAsignaciones();

    // Enviar formulario de asignación al servidor al submit
    asignacionForm.addEventListener('submit', enviarFormularioAsignacion);
});
