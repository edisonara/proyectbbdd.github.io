document.addEventListener('DOMContentLoaded', function () {
    const estanquesTableBody = document.querySelector('#estanquesTable tbody');
    const estanqueModal = new bootstrap.Modal(document.getElementById('estanqueModal'));
    const estanqueForm = document.getElementById('estanqueForm');
    const modalTitle = document.getElementById('modalTitle');
    const addEstanqueBtn = document.getElementById('addEstanqueBtn');

    let editingEstanque = false;

    async function fetchEstanques() {
        const response = await fetch('/api/estanques');
        const estanques = await response.json();
        renderEstanques(estanques);
    }

    function renderEstanques(estanques) {
        estanquesTableBody.innerHTML = '';
        estanques.forEach(estanque => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${estanque.id_estanque}</td>
                <td>${estanque.nombre_pez}</td>
                <td>${estanque.ubicacion}</td>
                <td>${estanque.capacidad}</td>
                <td>${estanque.tipo_alimento}</td>
                <td>${estanque.nombre_trabajador}</td>
                <td>${estanque.cantidad}</td>
                <td>${estanque.fecha_cosecha}</td>
                <td>
                    <button class="btn btn-warning btn-sm edit-btn" data-id="${estanque.id_estanque}">Editar</button>
                    <button class="btn btn-danger btn-sm delete-btn" data-id="${estanque.id_estanque}">Eliminar</button>
                </td>
            `;
            estanquesTableBody.appendChild(row);
        });

        document.querySelectorAll('.edit-btn').forEach(button => {
            button.addEventListener('click', handleEditEstanque);
        });

        document.querySelectorAll('.delete-btn').forEach(button => {
            button.addEventListener('click', handleDeleteEstanque);
        });
    }

    async function handleEditEstanque(event) {
        const id = event.target.getAttribute('data-id');
        const response = await fetch(`/api/estanques/${id}`);
        const estanque = await response.json();

        document.getElementById('estanqueId').value = estanque.id_estanque;
        document.getElementById('pezId').value = estanque.pez_id;
        document.getElementById('ubicacion').value = estanque.ubicacion;
        document.getElementById('capacidad').value = estanque.capacidad;
        document.getElementById('alimentacionId').value = estanque.alimentacion_id;
        document.getElementById('empleadoId').value = estanque.empleado_id;
        document.getElementById('cantidad').value = estanque.cantidad;
        document.getElementById('fechaCosecha').value = estanque.fecha_cosecha;

        modalTitle.textContent = 'Editar Estanque';
        estanqueModal.show();
        editingEstanque = true;
    }

    async function handleDeleteEstanque(event) {
        const id = event.target.getAttribute('data-id');
        if (confirm('¿Estás seguro de que deseas eliminar este estanque?')) {
            await fetch(`/api/estanques/${id}`, {
                method: 'DELETE',
            });
            fetchEstanques();
        }
    }

    async function populateSelects() {
        const [pecesResponse, alimentacionResponse, empleadosResponse] = await Promise.all([
            fetch('/api/peces'),
            fetch('/api/alimentacion'),
            fetch('/api/empleados')
        ]);

        const peces = await pecesResponse.json();
        const alimentaciones = await alimentacionResponse.json();
        const empleados = await empleadosResponse.json();

        const pezSelect = document.getElementById('pezId');
        const alimentacionSelect = document.getElementById('alimentacionId');
        const empleadoSelect = document.getElementById('empleadoId');

        peces.forEach(pez => {
            const option = document.createElement('option');
            option.value = pez.id_pez;
            option.textContent = pez.nombre;
            pezSelect.appendChild(option);
        });

        alimentaciones.forEach(alimento => {
            const option = document.createElement('option');
            option.value = alimento.id_alimentacion;
            option.textContent = alimento.tipo_alimento;
            alimentacionSelect.appendChild(option);
        });

        empleados.forEach(empleado => {
            const option = document.createElement('option');
            option.value = empleado.id_asignacion;
            option.textContent = `${empleado.nombre} ${empleado.apellido}`;
            empleadoSelect.appendChild(option);
        });
    }

    estanqueForm.addEventListener('submit', async function (event) {
        event.preventDefault();

        const id = document.getElementById('estanqueId').value;
        const pezId = document.getElementById('pezId').value;
        const ubicacion = document.getElementById('ubicacion').value;
        const capacidad = document.getElementById('capacidad').value;
        const alimentacionId = document.getElementById('alimentacionId').value;
        const empleadoId = document.getElementById('empleadoId').value;
        const cantidad = document.getElementById('cantidad').value;
        const fechaCosecha = document.getElementById('fechaCosecha').value;

        const data = {
            pez_id: pezId,
            ubicacion,
            capacidad,
            alimentacion_id: alimentacionId,
            empleado_id: empleadoId,
            cantidad,
            fecha_cosecha: fechaCosecha
        };

        if (editingEstanque) {
            await fetch(`/api/estanques/${id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
        } else {
            await fetch('/api/estanques', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
        }

        estanqueModal.hide();
        fetchEstanques();
    });

    addEstanqueBtn.addEventListener('click', () => {
        estanqueForm.reset();
        modalTitle.textContent = 'Agregar Estanque';
        estanqueModal.show();
        editingEstanque = false;
    });

    populateSelects();
    fetchEstanques();
});
